// src/store/index.js
import { configureStore } from "@reduxjs/toolkit";
import createSagaMiddleware from "redux-saga";
import sitesReducer from "./slices/sitesSlice";
import uiReducer from "./slices/uiSlice";
import insightsReducer from "./slices/insightsSlice"; // Add this import
import rootSaga from "./sagas/rootSaga";

const sagaMiddleware = createSagaMiddleware();

export const store = configureStore({
  reducer: {
    sites: sitesReducer,
    ui: uiReducer,
    insights: insightsReducer, // Add this reducer
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware().concat(sagaMiddleware),
});

sagaMiddleware.run(rootSaga);
