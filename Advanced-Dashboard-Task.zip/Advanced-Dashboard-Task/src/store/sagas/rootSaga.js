// src/store/sagas/rootSaga.js
import { all } from "redux-saga/effects";
import { sitesSaga } from "./sitesSaga";
import { insightsSaga } from "./insightsSaga"; // Add this import

export default function* rootSaga() {
  yield all([
    sitesSaga(),
    insightsSaga(), // Add this saga
  ]);
}
