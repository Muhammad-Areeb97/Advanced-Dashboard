import { call, put, takeEvery } from 'redux-saga/effects';
import axios from 'axios';
import { fetchSitesSuccess, fetchSitesFailure } from '../slices/sitesSlice';

function* fetchSites() {
  try {
    // Simulate API call
    const response = yield call(() => new Promise(resolve => {
      setTimeout(() => {
        const data = JSON.parse(localStorage.getItem('sites'));
        resolve({ data });
      }, 500);
    }));
    
    yield put(fetchSitesSuccess(response.data));
  } catch (error) {
    yield put(fetchSitesFailure(error.message));
  }
}

function* updateSite(action) {
  try {
    // Simulate API call
    yield call(() => new Promise(resolve => {
      setTimeout(() => {
        const sites = JSON.parse(localStorage.getItem('sites'));
        const updatedSites = sites.map(site => 
          site.id === action.payload.id ? action.payload : site
        );
        localStorage.setItem('sites', JSON.stringify(updatedSites));
        resolve();
      }, 500);
    }));
    
    yield put({ type: 'FETCH_SITES' });
  } catch (error) {
    console.error('Update failed:', error);
  }
}

export function* sitesSaga() {
  yield takeEvery('FETCH_SITES', fetchSites);
  yield takeEvery('UPDATE_SITE', updateSite);
}