// src/store/sagas/insightsSaga.js
import { call, put, takeEvery } from 'redux-saga/effects';
import { fetchInsightsSuccess, fetchInsightsFailure } from '../slices/insightsSlice';

function* fetchInsights() {
  try {
    // Simulate API call
    const response = yield call(() => new Promise(resolve => {
      setTimeout(() => {
        const data = JSON.parse(localStorage.getItem('multiSiteInsights') || '[]');
        resolve({ data });
      }, 500);
    }));
    
    yield put(fetchInsightsSuccess(response.data));
  } catch (error) {
    yield put(fetchInsightsFailure(error.message));
  }
}

export function* insightsSaga() {
  yield takeEvery('FETCH_INSIGHTS', fetchInsights);
}