// src/store/slices/uiSlice.js
import { createSlice } from '@reduxjs/toolkit';

// Load initial settings from localStorage or use defaults
const initialState = JSON.parse(localStorage.getItem('uiSettings')) || {
  showSummaryCards: true,
  showDataTable: true
};

export const uiSlice = createSlice({
  name: 'ui',
  initialState,
  reducers: {
    updateUISettings: (state, action) => {
      Object.assign(state, action.payload);
      localStorage.setItem('uiSettings', JSON.stringify(state));
    }
  }
});

export const { updateUISettings } = uiSlice.actions;
export default uiSlice.reducer;