import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  data: JSON.parse(localStorage.getItem('sites')) || [],
  loading: false,
  error: null
};

export const sitesSlice = createSlice({
  name: 'sites',
  initialState,
  reducers: {
    fetchSitesStart: (state) => {
      state.loading = true;
    },
    fetchSitesSuccess: (state, action) => {
      state.data = action.payload;
      state.loading = false;
    },
    fetchSitesFailure: (state, action) => {
      state.error = action.payload;
      state.loading = false;
    },
    updateSite: (state, action) => {
      const index = state.data.findIndex(site => site.id === action.payload.id);
      if (index !== -1) {
        state.data[index] = action.payload;
        localStorage.setItem('sites', JSON.stringify(state.data));
      }
    }
  }
});

export const { fetchSitesStart, fetchSitesSuccess, fetchSitesFailure, updateSite } = sitesSlice.actions;
export default sitesSlice.reducer;