// src/store/slices/insightsSlice.js
import { createSlice } from "@reduxjs/toolkit";

// Safely get initial data
const getInitialData = () => {
  try {
    const storedData = localStorage.getItem("multiSiteInsights");
    return storedData ? JSON.parse(storedData) : [];
  } catch (error) {
    console.error("Failed to parse insights data:", error);
    return [];
  }
};

const initialState = {
  data: getInitialData(),
  loading: false,
  error: null,
};

export const insightsSlice = createSlice({
  name: "insights",
  initialState,
  reducers: {
    fetchInsightsStart: (state) => {
      state.loading = true;
      state.error = null;
    },
    fetchInsightsSuccess: (state, action) => {
      state.data = action.payload;
      state.loading = false;
      // Persist to localStorage
      try {
        localStorage.setItem(
          "multiSiteInsights",
          JSON.stringify(action.payload)
        );
      } catch (error) {
        console.error("Failed to save insights:", error);
      }
    },
    fetchInsightsFailure: (state, action) => {
      state.error = action.payload;
      state.loading = false;
    },
  },
});

export const {
  fetchInsightsStart,
  fetchInsightsSuccess,
  fetchInsightsFailure,
} = insightsSlice.actions;

export default insightsSlice.reducer;
