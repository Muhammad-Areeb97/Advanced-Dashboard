// utils/loadInitialData.js
import sitesData from "../sites.json";
import insightsData from "../multiSiteInsights.json";
import settingsData from "../uiSettings.json";

export const loadInitialData = () => {
  if (!localStorage.getItem("sites")) {
    localStorage.setItem("sites", JSON.stringify(sitesData));
  }

  if (!localStorage.getItem("multiSiteInsights")) {
    localStorage.setItem("multiSiteInsights", JSON.stringify(insightsData));
  }

  if (!localStorage.getItem("uiSettings")) {
    localStorage.setItem("uiSettings", JSON.stringify(settingsData));
  }
};
