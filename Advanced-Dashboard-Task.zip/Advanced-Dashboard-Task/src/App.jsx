import React, { useEffect } from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { Provider } from "react-redux";
import { store } from "./store";
import { loadInitialData } from "./utils/loadInitialData";
import TopBar from "./components/TopBar";
import Dashboard from "./pages/Dashboard";
import Insights from "./pages/Insights";
import { fetchInsightsStart } from "./store/slices/insightsSlice";

// Load initial data into localStorage
loadInitialData();

const App = () => {
  useEffect(() => {
    store.dispatch(fetchInsightsStart());
  }, []);

  return (
    <Provider store={store}>
      <BrowserRouter>
        <div className="app">
          <TopBar />
          <Routes>
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/insights" element={<Insights />} />
            <Route path="*" element={<Dashboard />} />
          </Routes>
        </div>
      </BrowserRouter>
    </Provider>
  );
};

export default App;
