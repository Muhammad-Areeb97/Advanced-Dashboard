import { useSelector } from "react-redux";
import { useEffect } from "react";
import { useDispatch } from "react-redux";
import SummaryCards from "../components/SummaryCards";
import SitesTable from "../components/SitesTable";
import SettingsDrawer from "../components/SettingsDrawer";

import { Layout, Typography, Divider, Row, Col, Card } from "antd";
import { DashboardOutlined } from "@ant-design/icons";
import "./styles/Dashboard.css"; // CSS styles specific to Dashboard

const { Content } = Layout;
const { Title, Paragraph } = Typography;

export default function Dashboard() {
  const dispatch = useDispatch();
  const uiState = useSelector((state) => state.ui) || {}; // Fallback to empty object
  const { showSummaryCards = true, showDataTable = true } = uiState; // Default values

  useEffect(() => {
    dispatch({ type: "FETCH_SITES" });
  }, [dispatch]);

  return (
    <Layout className="dashboard-layout">
      <Content className="dashboard-content">
        <Card className="hero-card" bordered={false}>
          <Row align="middle" justify="space-between">
            <Col xs={24} md={16}>
              <Title level={2} className="hero-title">
                <DashboardOutlined className="hero-icon" />
                Welcome to the Advanced Monitoring Dashboard
              </Title>
              <Paragraph className="hero-subtitle">
                Manage and visualize your site's operational data and trends all
                in one place.
              </Paragraph>
            </Col>
          </Row>
        </Card>

        {showSummaryCards && (
          <>
            <Divider orientation="left">Overview</Divider>
            <SummaryCards />
          </>
        )}

        {showDataTable && (
          <>
            <Divider orientation="left">Site Information</Divider>
            <SitesTable />
          </>
        )}

        <SettingsDrawer />
      </Content>
    </Layout>
  );
}
