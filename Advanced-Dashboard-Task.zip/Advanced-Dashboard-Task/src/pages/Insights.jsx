import { useEffect } from "react";
import { useDispatch } from "react-redux";
import MultiSiteCharts from "../components/MultiSiteCharts";
import "./styles/Insights.css";

export default function Insights() {
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch({ type: "FETCH_INSIGHTS" });
  }, [dispatch]);

  return (
    <div className="insights-page">
      <h2 className="headingmultiste">Multi-Site Insights</h2>
      <MultiSiteCharts />
    </div>
  );
}
