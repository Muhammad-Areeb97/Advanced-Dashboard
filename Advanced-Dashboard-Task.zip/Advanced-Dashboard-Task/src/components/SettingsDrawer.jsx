import { Drawer, Checkbox, Button } from 'antd';
import { useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { updateUISettings } from '../store/slices/uiSlice';

export default function SettingsDrawer() {
  const [visible, setVisible] = useState(false);
  const { showSummaryCards, showDataTable } = useSelector(state => state.ui);
  const dispatch = useDispatch();
  
  const handleChange = (key, value) => {
    dispatch(updateUISettings({ [key]: value }));
  };
  
  return (
    <>
      <Button type="primary" onClick={() => setVisible(true)} style={{ margin: 16 }}>
        Settings
      </Button>
      <Drawer 
        title="Dashboard Settings" 
        placement="right" 
        onClose={() => setVisible(false)}
        visible={visible}
      >
        <Checkbox 
          checked={showSummaryCards}
          onChange={(e) => handleChange('showSummaryCards', e.target.checked)}
        >
          Show Summary Cards
        </Checkbox>
        <br />
        <Checkbox 
          checked={showDataTable}
          onChange={(e) => handleChange('showDataTable', e.target.checked)}
        >
          Show Data Table
        </Checkbox>
      </Drawer>
    </>
  );
}