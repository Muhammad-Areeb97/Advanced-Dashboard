import ReactECharts from "echarts-for-react";
import { useSelector } from "react-redux";
import { Spin } from "antd";
import "./styles/MultiCharts.css";

export default function MultiSiteCharts() {
  const {
    data: insights = [],
    loading,
    error,
  } = useSelector((state) => state.insights);

  if (loading) {
    return (
      <div
        style={{ display: "flex", justifyContent: "center", padding: "40px" }}
      >
        <Spin size="large" />
      </div>
    );
  }

  if (error) {
    return (
      <div style={{ color: "red", padding: "20px", textAlign: "center" }}>
        Error loading insights: {error}
      </div>
    );
  }

  if (!insights || insights.length === 0) {
    return (
      <div style={{ padding: "20px", textAlign: "center" }}>
        No insights data available
      </div>
    );
  }

  const lineChartOption = {
    title: {
      text: "Multi-Site Trend Comparison",
      textStyle: {
        color: "#2c3e50",
        fontSize: 18,
        fontWeight: "bold",
        align: "center",
      },
      left: "center",
      top: "10px",
    },
    tooltip: {
      trigger: "axis",
    },
    legend: {
      data: insights.map((item) => item.siteName),
      top: "40px",
    },
    grid: {
      left: "3%",
      right: "4%",
      bottom: "3%",
      containLabel: true,
    },
    xAxis: {
      type: "category",
      data: ["Day 1", "Day 2", "Day 3", "Day 4", "Day 5"],
    },
    yAxis: {
      type: "value",
    },
    series: insights.map((site) => ({
      name: site.siteName,
      type: "line",
      smooth: true,
      lineStyle: {
        width: 3,
      },
      symbolSize: 8,
      data: site.trend,
    })),
  };

  return (
    <div className="multi-site-chart-container">
      <ReactECharts
        option={lineChartOption}
        style={{ height: "400px", width: "100%" }}
      />
    </div>
  );
}
