import { Card, Row, Col } from 'antd';
import { useSelector } from 'react-redux';

export default function SummaryCards() {
  const sites = useSelector(state => state.sites.data);
  
  const totalSites = sites.length;
  const totalAlarms = sites.reduce((sum, site) => sum + site.alarms, 0);
  const totalTickets = sites.reduce((sum, site) => sum + site.tickets, 0);
  const totalDevices = sites.reduce((sum, site) => sum + site.devices, 0);
  
  return (
    <Row gutter={16}>
      <Col span={6}>
        <Card title="Total Sites" bordered={false}>
          {totalSites}
        </Card>
      </Col>
      <Col span={6}>
        <Card title="Total Alarms" bordered={false}>
          {totalAlarms}
        </Card>
      </Col>
      <Col span={6}>
        <Card title="Total Tickets" bordered={false}>
          {totalTickets}
        </Card>
      </Col>
      <Col span={6}>
        <Card title="Total Devices" bordered={false}>
          {totalDevices}
        </Card>
      </Col>
    </Row>
  );
}