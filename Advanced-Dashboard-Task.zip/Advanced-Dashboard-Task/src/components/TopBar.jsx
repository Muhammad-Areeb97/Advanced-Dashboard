import { Menu } from "antd";
import { Link, useLocation } from "react-router-dom";
import "./styles/TopBar.css";

export default function TopBar() {
  const location = useLocation();

  return (
    <Menu
      mode="horizontal"
      selectedKeys={[location.pathname]}
      className="topbar-menu"
    >
      <Menu.Item key="/dashboard">
        <Link to="/dashboard">Dashboard</Link>
      </Menu.Item>
      <Menu.Item key="/insights">
        <Link to="/insights">Insights</Link>
      </Menu.Item>
    </Menu>
  );
}
