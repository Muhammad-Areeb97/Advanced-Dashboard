import { Modal, Spin } from 'antd';
import ReactECharts from 'echarts-for-react';

export default function SiteInsightsModal({ visible, onClose, site }) {
  if (!site) return null;

  const chartOption = {
    title: { text: `${site.name} Insights` },
    xAxis: { type: 'category', data: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'] },
    yAxis: { type: 'value' },
    series: [{ data: site.insights, type: 'line' }]
  };

  return (
    <Modal 
      title="Site Insights" 
      open={visible} 
      onCancel={onClose}
      footer={null}
      width={800}
    >
      <ReactECharts option={chartOption} style={{ height: 400 }} />
    </Modal>
  );
}