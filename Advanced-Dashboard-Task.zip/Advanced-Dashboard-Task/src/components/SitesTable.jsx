import { Table, Button, Space, Input } from "antd";
import { useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import SiteInsightsModal from "./SiteInsightsModal";
import "./styles/sitesTable.css"
export default function SitesTable() {
  const dispatch = useDispatch();
  const sites = useSelector((state) => state.sites.data || []);
  const [editingId, setEditingId] = useState(null);
  const [editedData, setEditedData] = useState({});
  const [modalVisible, setModalVisible] = useState(false);
  const [selectedSite, setSelectedSite] = useState(null);

  const handleEdit = (record) => {
    setEditingId(record.id);
    setEditedData({ ...record });
  };

  const handleSave = () => {
    dispatch({ type: "UPDATE_SITE", payload: editedData });
    setEditingId(null);
  };

  const handleChange = (e, field) => {
    setEditedData({ ...editedData, [field]: e.target.value });
  };

  const showInsights = (site) => {
    setSelectedSite(site);
    setModalVisible(true);
  };

  const columns = [
    {
      title: "ID",
      dataIndex: "id",
      key: "id",
    },
    {
      title: "Site Name",
      dataIndex: "name",
      key: "name",
      render: (text, record) =>
        editingId === record.id ? (
          <Input
            value={editedData.name}
            onChange={(e) => handleChange(e, "name")}
          />
        ) : (
          text
        ),
    },
    {
      title: "Status",
      dataIndex: "status",
      key: "status",
      render: (text, record) =>
        editingId === record.id ? (
          <Input
            value={editedData.status}
            onChange={(e) => handleChange(e, "status")}
          />
        ) : (
          text
        ),
    },
    {
      title: "Alarms",
      dataIndex: "alarms",
      key: "alarms",
      render: (text, record) =>
        editingId === record.id ? (
          <Input
            value={editedData.alarms}
            onChange={(e) => handleChange(e, "alarms")}
          />
        ) : (
          text
        ),
    },
    {
      title: "Tickets",
      dataIndex: "tickets",
      key: "tickets",
      render: (text, record) =>
        editingId === record.id ? (
          <Input
            value={editedData.tickets}
            onChange={(e) => handleChange(e, "tickets")}
          />
        ) : (
          text
        ),
    },
    {
      title: "Devices",
      dataIndex: "devices",
      key: "devices",
      render: (text, record) =>
        editingId === record.id ? (
          <Input
            value={editedData.devices}
            onChange={(e) => handleChange(e, "devices")}
          />
        ) : (
          text
        ),
    },
    {
      title: "Last Updated",
      dataIndex: "lastUpdated",
      key: "lastUpdated",
      render: (text, record) =>
        editingId === record.id ? (
          <Input
            value={editedData.lastUpdated}
            onChange={(e) => handleChange(e, "lastUpdated")}
          />
        ) : (
          text
        ),
    },
    {
      title: "Action",
      key: "action",
      render: (_, record) => (
        <Space size="middle">
          {editingId === record.id ? (
            <Button type="primary" onClick={handleSave}>
              Save
            </Button>
          ) : (
            <Button onClick={() => handleEdit(record)}>Edit</Button>
          )}
          <Button onClick={() => showInsights(record)}>Insights</Button>
        </Space>
      ),
    },
  ];

  return (
    <>
      <Table
        columns={columns}
        dataSource={sites}
        rowKey="id"
        pagination={false}
      />
      <SiteInsightsModal
        visible={modalVisible}
        onClose={() => setModalVisible(false)}
        site={selectedSite}
      />
    </>
  );
}
